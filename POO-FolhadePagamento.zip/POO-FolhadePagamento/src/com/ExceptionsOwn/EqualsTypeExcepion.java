package com.ExceptionsOwn;

public class EqualsTypeExcepion extends RuntimeException {
    public EqualsTypeExcepion(String s){ super(s); }
}
